package com.zara.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Accessibility service: lets Zara see the screen and tap / swipe / type when the user enables it. */
class ZaraAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: ZaraAccessibilityService? = null
    }

    private val shotExecutor = Executors.newSingleThreadExecutor()

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun activePackage(): String? = rootInActiveWindow?.packageName?.toString()

    fun screenSize(): Pair<Int, Int> {
        val m = resources.displayMetrics
        return m.widthPixels to m.heightPixels
    }

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
            .build()
        val latch = CountDownLatch(1)
        var ok = false
        val dispatched = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
        }, null)
        if (!dispatched) return false
        latch.await(durationMs + 3000, TimeUnit.MILLISECONDS)
        return ok
    }

    fun tap(x: Float, y: Float, holdMs: Long = 45): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, holdMs)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return gesture(p, durationMs)
    }

    private fun findScrollable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        fun walk(x: AccessibilityNodeInfo?) {
            if (x == null) return
            if (x.isScrollable && x.isVisibleToUser) {
                val r = Rect(); x.getBoundsInScreen(r)
                val a = r.width() * r.height()
                if (a > bestArea) { bestArea = a; best = x }
            }
            for (i in 0 until x.childCount) walk(x.getChild(i))
        }
        walk(root)
        return best
    }

    /** Native scroll (no finger gesture): instant and perfectly smooth. Returns false if the app does not support it. */
    private fun scrollByAction(direction: String): Boolean {
        val act = when (direction.lowercase()) {
            "down" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN
            "up" -> AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP
            else -> return false
        }
        val node = findScrollable(rootInActiveWindow) ?: return false
        return node.performAction(act.id)
    }

    /** Waits (max [maxMs]) until the foreground window changes from [before]; used after opening an app. */
    fun waitForWindowChange(before: String?, maxMs: Long) {
        val end = System.currentTimeMillis() + maxMs
        while (System.currentTimeMillis() < end) {
            val now = activePackage()
            if (now != null && now != before) { try { Thread.sleep(120) } catch (_: InterruptedException) {}; return }
            try { Thread.sleep(50) } catch (_: InterruptedException) { return }
        }
    }

    fun scroll(direction: String): Boolean {
        if (scrollByAction(direction)) return true
        val (w, h) = screenSize()
        val cx = w / 2f
        val cy = h / 2f
        return when (direction.lowercase()) {
            // "down" = see content further down the page = finger moves up
            "down" -> swipe(cx, h * 0.72f, cx, h * 0.28f, 260)
            "up" -> swipe(cx, h * 0.28f, cx, h * 0.72f, 260)
            "left" -> swipe(w * 0.2f, cy, w * 0.8f, cy, 260)
            "right" -> swipe(w * 0.8f, cy, w * 0.2f, cy, 260)
            else -> false
        }
    }

    fun press(key: String): Boolean {
        val action = when (key.lowercase()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            else -> return false
        }
        return performGlobalAction(action)
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Screen is not readable right now (no active window)."
        val (w, h) = screenSize()
        val sb = StringBuilder("Screen size ${w}x${h} px. Elements as: label @(centerX,centerY) [flags]\n")
        var count = 0
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || count >= 200 || !n.isVisibleToUser) return
            val label = if (n.isPassword) "(password field)" else listOf(
                n.text?.toString()?.trim().orEmpty(),
                n.contentDescription?.toString()?.trim().orEmpty()
            ).filter { it.isNotEmpty() }.distinct().joinToString(" | ")
            if (label.isNotEmpty() || n.isClickable || n.isEditable) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val flags = ArrayList<String>()
                if (n.isClickable) flags.add("tap")
                if (n.isEditable) flags.add("input")
                if (n.isScrollable) flags.add("scroll")
                if (n.isChecked) flags.add("checked")
                sb.append("- ")
                    .append(if (label.isEmpty()) "(unlabeled ${n.className?.toString()?.substringAfterLast('.')})" else label.take(120))
                    .append(" @(").append(r.centerX()).append(',').append(r.centerY()).append(')')
                if (flags.isNotEmpty()) sb.append(" [").append(flags.joinToString(",")).append(']')
                sb.append('\n')
                count++
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        if (count == 0) sb.append("(no readable elements; the screen may be an image/game/video or protected)\n")
        return sb.toString()
    }

    fun clickText(text: String): String {
        val root = rootInActiveWindow ?: return "error: no active window"
        val target = root.findAccessibilityNodeInfosByText(text).firstOrNull { it.isVisibleToUser }
            ?: return "error: no visible element with text '$text'. Call look_at_screen first."
        var n: AccessibilityNodeInfo? = target
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok: clicked '$text'"
        val r = Rect()
        target.getBoundsInScreen(r)
        return if (tap(r.centerX().toFloat(), r.centerY().toFloat())) "ok: tapped '$text' at (${r.centerX()},${r.centerY()})"
        else "error: could not click '$text'"
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun typeText(text: String): String {
        val root = rootInActiveWindow ?: return "error: no active window"
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
            ?: return "error: no text field found. Tap a text field first."
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "ok: typed" else "error: could not type into the field"
    }

    private fun findNode(n: AccessibilityNodeInfo?, match: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isVisibleToUser && match(n)) return n
        for (i in 0 until n.childCount) findNode(n.getChild(i), match)?.let { return it }
        return null
    }

    /** Waits up to [timeoutMs] for a visible node accepted by [match], then clicks it (no screen reading by the model). */
    fun waitAndClick(timeoutMs: Long, match: (AccessibilityNodeInfo) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            val hit = rootInActiveWindow?.let { findNode(it, match) }
            if (hit != null) {
                var n: AccessibilityNodeInfo? = hit
                while (n != null && !n.isClickable) n = n.parent
                if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                val r = Rect(); hit.getBoundsInScreen(r)
                if (tap(r.centerX().toFloat(), r.centerY().toFloat())) return true
            }
            try { Thread.sleep(150) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    fun openApp(name: String): String {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
        val n = name.trim().lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: return "error: no installed app named '$name'"
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "error: cannot launch '$name'"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { startActivity(intent); "ok: opened ${match.loadLabel(pm)}" } catch (e: Exception) { "error: ${e.message}" }
    }

    /** JPEG (max 720 px wide) of the current screen, or null if unsupported / blocked. */
    fun screenshotJpeg(): ByteArray? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var result: ByteArray? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, shotExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                try {
                    val hw = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    screenshot.hardwareBuffer.close()
                    if (soft != null) {
                        val scale = 640f / soft.width.coerceAtLeast(1)
                        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(soft, 640, (soft.height * scale).toInt().coerceAtLeast(1), true) else soft
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 60, out)
                        result = out.toByteArray()
                    }
                } catch (_: Exception) {
                } finally {
                    latch.countDown()
                }
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(3, TimeUnit.SECONDS)
        return result
    }
}

/** Executes the phone-control tools that Gemini calls during the live voice call. */
object PhoneControl {
    private const val OFF = "Phone control is OFF. Tell the user to open Zara > Settings > Phone control and enable 'Zara Phone Control' in Accessibility settings."

    fun isEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(ctx.packageName + "/")
    }

    private fun obj(k: String, v: String) = JSONObject().put(k, v)

    private fun fn(name: String, desc: String, props: Map<String, Pair<String, String>> = emptyMap()): JSONObject {
        val f = JSONObject().put("name", name).put("description", desc)
        if (props.isNotEmpty()) {
            val p = JSONObject()
            props.forEach { (k, v) -> p.put(k, JSONObject().put("type", v.first).put("description", v.second)) }
            f.put("parameters", JSONObject().put("type", "OBJECT").put("properties", p).put("required", JSONArray(props.keys.toList())))
        }
        return f
    }

    /** Tool declarations for the Gemini Live setup message. */
    fun declarations(): JSONArray = JSONArray()
        .put(fn("call_contact", "Phone call a contact by name (or a phone number) DIRECTLY, no screen needed. Use this for any 'call X' request.", mapOf("who" to ("STRING" to "contact name as the user said it, or digits"))))
        .put(fn("send_sms", "Send a normal SMS text message DIRECTLY, no screen needed.", mapOf("who" to ("STRING" to "contact name or number"), "message" to ("STRING" to "message text"))))
        .put(fn("send_whatsapp", "Send a WhatsApp message DIRECTLY (opens the chat and presses send itself), no screen needed.", mapOf("who" to ("STRING" to "contact name or number"), "message" to ("STRING" to "message text"))))
        .put(fn("play_youtube", "Search YouTube for a song/video and start playing the first result DIRECTLY, no screen needed.", mapOf("query" to ("STRING" to "song or video name, plus artist if known"))))
        .put(fn("look_at_screen", "Read what is currently on the phone screen (text, buttons, coordinates) and also see a screenshot. Call this before tapping and after each action to confirm the result."))
        .put(fn("tap", "Tap the screen at pixel coordinates taken from look_at_screen.", mapOf("x" to ("INTEGER" to "X pixel"), "y" to ("INTEGER" to "Y pixel"))))
        .put(fn("long_press", "Long-press at pixel coordinates.", mapOf("x" to ("INTEGER" to "X pixel"), "y" to ("INTEGER" to "Y pixel"))))
        .put(fn("swipe", "Swipe from one point to another (pixel coordinates).", mapOf(
            "x1" to ("INTEGER" to "start X"), "y1" to ("INTEGER" to "start Y"),
            "x2" to ("INTEGER" to "end X"), "y2" to ("INTEGER" to "end Y"),
            "duration_ms" to ("INTEGER" to "duration in milliseconds, e.g. 300"))))
        .put(fn("scroll", "Scroll the current screen.", mapOf("direction" to ("STRING" to "down, up, left or right (down = reveal content further down)"))))
        .put(fn("click_text", "Click the visible element whose text or label contains the given text.", mapOf("text" to ("STRING" to "text or label to click"))))
        .put(fn("type_text", "Type text into the focused or first visible text field (replaces its content).", mapOf("text" to ("STRING" to "text to type"))))
        .put(fn("press_key", "Press a system button.", mapOf("key" to ("STRING" to "back, home, recents, notifications, quick_settings or lock_screen"))))
        .put(fn("save_memory", "Save an important fact about the user (name, preferences, plans, routines) so you remember it in every future chat and call.", mapOf("fact" to ("STRING" to "short fact to remember"))))
        .put(fn("open_app", "Open an installed app by its name, e.g. WhatsApp, YouTube, Settings, Camera.", mapOf("name" to ("STRING" to "app name"))))

    /** Runs a tool call. Blocking: call from a background thread. [sendFrame] receives screenshot JPEG bytes. */
    fun execute(name: String, args: JSONObject, sendFrame: (ByteArray) -> Unit): JSONObject {
        if (name == "save_memory") {
            Memory.addFact(args.optString("fact"))
            return obj("result", "ok: saved to permanent memory")
        }
        val inst = ZaraAccessibilityService.instance
        (inst ?: LiveSession.appContext)?.let { c -> DirectActions.execute(name, args, c, inst)?.let { return it } }
        val svc = inst ?: return obj("error", OFF)
        fun settle() { try { Thread.sleep(60) } catch (_: InterruptedException) {} }
        fun res(s: String) = obj("result", s)
        fun ok(b: Boolean, what: String) = res(if (b) "ok: $what" else "error: $what failed").also { settle() }

        return when (name) {
            "look_at_screen" -> {
                // text first (fast); screenshot is sent in parallel
                Thread { try { svc.screenshotJpeg()?.let { sendFrame(it) } } catch (_: Exception) {} }.start()
                res(svc.readScreen())
            }
            "tap" -> ok(svc.tap(args.optDouble("x").toFloat(), args.optDouble("y").toFloat()), "tap")
            "long_press" -> ok(svc.tap(args.optDouble("x").toFloat(), args.optDouble("y").toFloat(), 900), "long press")
            "swipe" -> ok(svc.swipe(
                args.optDouble("x1").toFloat(), args.optDouble("y1").toFloat(),
                args.optDouble("x2").toFloat(), args.optDouble("y2").toFloat(),
                args.optLong("duration_ms", 300).coerceIn(50, 3000)), "swipe")
            "scroll" -> ok(svc.scroll(args.optString("direction", "down")), "scroll")
            "click_text" -> res(svc.clickText(args.optString("text"))).also { settle() }
            "type_text" -> res(svc.typeText(args.optString("text"))).also { settle() }
            "press_key" -> ok(svc.press(args.optString("key")), "press ${args.optString("key")}")
            "open_app" -> {
                val before = svc.activePackage()
                val r = svc.openApp(args.optString("name"))
                if (r.startsWith("ok")) svc.waitForWindowChange(before, 1800)
                res(r)
            }
            else -> obj("error", "unknown tool $name")
        }
    }

    fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)
}
