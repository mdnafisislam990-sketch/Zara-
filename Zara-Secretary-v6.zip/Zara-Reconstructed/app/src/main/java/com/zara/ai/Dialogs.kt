package com.zara.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
internal fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, color = if (selected) Color.White else Soft, fontSize = 13.sp,
        modifier = Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) Purple else Color(0xFF1D1B38))
            .clickable { onClick() }.padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
internal fun ChipRows(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    options.chunked(3).forEach { row ->
        Row(Modifier.padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { o -> Chip(o, o == selected) { onSelect(o) } }
        }
    }
}

@Composable
private fun Section(text: String) {
    Text(text, color = Lavender, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
internal fun VoiceLangDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var voice by remember { mutableStateOf(Prefs.voice(ctx)) }
    var lang by remember { mutableStateOf(Prefs.language(ctx)) }
    AlertDialog(
        onDismissRequest = onClose, containerColor = Card,
        title = { Text("Voice & language", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Section("ZARA'S VOICE")
                ChipRows(Prefs.VOICES, voice) { voice = it; Prefs.put(ctx, "voice", it) }
                Section("REPLY LANGUAGE")
                ChipRows(Prefs.LANGS, lang) { lang = it; Prefs.put(ctx, "language", it) }
                Text("Applies from the next call / message.", color = Soft, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}

@Composable
internal fun LookFeelDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(Prefs.accent(ctx)) }
    AlertDialog(
        onDismissRequest = onClose, containerColor = Card,
        title = { Text("Look & feel", color = Color.White) },
        text = {
            Column {
                Section("ACCENT COLOR")
                ChipRows(Prefs.ACCENTS.map { it.first }, Prefs.ACCENTS.first { it.second == sel }.first) { name ->
                    val v = Prefs.ACCENTS.first { it.first == name }.second
                    sel = v; Prefs.setAccent(ctx, v); Purple = Color(v)
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}

@Composable
internal fun KeyboardDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf(Prefs.sttLang(ctx)) }
    AlertDialog(
        onDismissRequest = onClose, containerColor = Card,
        title = { Text("Voice keyboard", color = Color.White) },
        text = {
            Column {
                Text("Tap the mic in Chat to dictate. Choose the language you speak:", color = Soft, fontSize = 12.sp)
                ChipRows(Prefs.STT.map { it.first }, Prefs.STT.firstOrNull { it.second == sel }?.first ?: "English") { name ->
                    val v = Prefs.STT.first { it.first == name }.second
                    sel = v; Prefs.put(ctx, "stt_lang", v)
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}

@Composable
internal fun CallSettingsDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var speaker by remember { mutableStateOf(Prefs.speaker(ctx)) }
    var confirm by remember { mutableStateOf(Prefs.confirmSensitive(ctx)) }
    var watch by remember { mutableStateOf(Prefs.watchScreen(ctx)) }
    AlertDialog(
        onDismissRequest = onClose, containerColor = Card,
        title = { Text("Call settings", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Speakerphone", color = Color.White); Text("Play Zara's voice on the loudspeaker", color = Soft, fontSize = 11.sp) }
                    Switch(speaker, { speaker = it; Prefs.putBool(ctx, "speaker", it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Confirm risky actions", color = Color.White); Text("Zara asks before sending, paying, deleting, calling", color = Soft, fontSize = 11.sp) }
                    Switch(confirm, { confirm = it; Prefs.putBool(ctx, "confirm_sensitive", it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Live screen view", color = Color.White); Text("Zara watches your screen during a call (needs Phone control ON)", color = Soft, fontSize = 11.sp) }
                    Switch(watch, { watch = it; Prefs.putBool(ctx, "watch_screen", it) })
                }
                Text("Applies from the next call.", color = Soft, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}

@Composable
internal fun MemoryDialog(onClose: () -> Unit) {
    val ver by Memory.version.collectAsState()
    val facts = remember(ver) { Memory.factsList() }
    val (_, chats) = remember(ver) { Memory.counts() }
    var newFact by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose, containerColor = Card,
        title = { Text("Chats & memory", color = Color.White) },
        text = {
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Zara remembers all $chats saved chats, calls and phone actions, even after you close the app or change the API key.", color = Soft, fontSize = 12.sp)
                Section("SAVED FACTS")
                if (facts.isEmpty()) Text("Nothing yet. Tell Zara things like 'remember my name is ...'.", color = Soft, fontSize = 12.sp)
                facts.forEachIndexed { i, f ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(f, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.Close, null, tint = Soft, modifier = Modifier.clickable { Memory.removeFact(i) })
                    }
                }
                OutlinedTextField(newFact, { newFact = it }, label = { Text("Add a fact") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { Memory.addFact(newFact); newFact = "" }) { Text("Add") }
                    TextButton(onClick = { Memory.clearFacts() }) { Text("Clear facts") }
                    TextButton(onClick = { Memory.clearChats() }) { Text("Clear chats") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}
