package com.zara.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Direct actions: Zara does these with Android intents / APIs, WITHOUT looking at the screen.
 *   call_contact, send_sms, send_whatsapp, play_youtube
 */
object DirectActions {
    private const val YT = "com.google.android.youtube"
    private const val WA = "com.whatsapp"

    private fun has(ctx: Context, p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun res(s: String) = JSONObject().put("result", s)

    private class Contact(val name: String, val number: String)

    // ---------- contacts ----------

    // Keep Bengali matras: only strip spaces and punctuation, never letter marks.
    private fun norm(s: String) = s.lowercase().filter { !it.isWhitespace() && it != '.' && it != '-' && it != '_' }

    private fun findContacts(ctx: Context, query: String): List<Contact> {
        val q = norm(query)
        if (q.isEmpty()) return emptyList()
        val all = ArrayList<Contact>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0) ?: continue
                val num = c.getString(1) ?: continue
                if (norm(n).contains(q)) all.add(Contact(n, num))
            }
        }
        val exact = all.filter { norm(it.name) == q }
        return (if (exact.isNotEmpty()) exact else all).distinctBy { it.number.filter { ch -> ch.isDigit() }.takeLast(10) }
    }

    /** Returns a contact, or an error string for the model. */
    private fun resolve(ctx: Context, who: String): Pair<Contact?, String?> {
        val w = who.trim()
        if (w.isEmpty()) return null to "error: no name or number given. Ask the user who."
        if (w.none { it.isLetter() } && w.count { it.isDigit() } >= 5)
            return Contact(w, w.filter { it.isDigit() || it == '+' }) to null
        if (!has(ctx, Manifest.permission.READ_CONTACTS))
            return null to "error: Contacts permission is not granted. Tell the user to allow Contacts for Zara in Android App info > Permissions."
        val m = findContacts(ctx, w)
        return when {
            m.isEmpty() -> null to "error: no contact matching '$w'. Ask the user to repeat the name or say the phone number."
            m.map { it.name }.distinct().size > 1 ->
                null to "error: several contacts match: ${m.take(5).joinToString { it.name }}. Ask the user which one."
            else -> m[0] to null
        }
    }

    private fun launch(ctx: Context, i: Intent): String? {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); null } catch (e: Exception) { "error: ${e.message}" }
    }

    // ---------- tools ----------

    fun call(ctx: Context, who: String): JSONObject {
        if (!has(ctx, Manifest.permission.CALL_PHONE))
            return res("error: Phone-call permission is not granted. Tell the user to allow Phone for Zara in Android App info > Permissions.")
        val (c, err) = resolve(ctx, who)
        if (c == null) return res(err ?: "error: contact not found")
        launch(ctx, Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(c.number))))?.let { return res(it) }
        return res("ok: calling ${c.name}")
    }

    fun sms(ctx: Context, who: String, text: String): JSONObject {
        if (text.isBlank()) return res("error: empty message. Ask the user what to write.")
        if (!has(ctx, Manifest.permission.SEND_SMS))
            return res("error: SMS permission is not granted. Tell the user to allow SMS for Zara in Android App info > Permissions.")
        val (c, err) = resolve(ctx, who)
        if (c == null) return res(err ?: "error: contact not found")
        return try {
            val sm: SmsManager =
                if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                else @Suppress("DEPRECATION") SmsManager.getDefault()
            sm.sendMultipartTextMessage(c.number, null, sm.divideMessage(text), null, null)
            res("ok: SMS sent to ${c.name}")
        } catch (e: Exception) {
            res("error: SMS failed: ${e.message}")
        }
    }

    private fun countryCode(ctx: Context): String? {
        val iso = (ctx.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager)?.simCountryIso?.uppercase()?.takeIf { it.isNotBlank() }
            ?: java.util.Locale.getDefault().country
        return mapOf(
            "BD" to "880", "IN" to "91", "PK" to "92", "NP" to "977", "LK" to "94", "US" to "1", "CA" to "1",
            "GB" to "44", "SA" to "966", "AE" to "971", "QA" to "974", "KW" to "965", "OM" to "968",
            "MY" to "60", "SG" to "65", "IT" to "39", "DE" to "49", "FR" to "33", "AU" to "61"
        )[iso]
    }

    private fun waNumber(ctx: Context, raw: String): String? {
        val digits = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return digits
        if (raw.trim().startsWith("00")) return digits.drop(2)
        val cc = countryCode(ctx) ?: return null
        return if (digits.startsWith("0")) cc + digits.drop(1) else if (digits.startsWith(cc)) digits else cc + digits
    }

    fun whatsapp(ctx: Context, svc: ZaraAccessibilityService?, who: String, text: String): JSONObject {
        if (text.isBlank()) return res("error: empty message. Ask the user what to write.")
        val (c, err) = resolve(ctx, who)
        if (c == null) return res(err ?: "error: contact not found")
        val num = waNumber(ctx, c.number) ?: return res("error: cannot work out the country code for ${c.name}. Ask for the number with country code.")
        val uri = Uri.parse("https://wa.me/$num?text=" + URLEncoder.encode(text, "UTF-8"))
        launch(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage(WA))?.let { return res("error: WhatsApp is not installed or cannot open ($it)") }
        if (svc == null) return res("ok: WhatsApp chat with ${c.name} opened with the message typed, but phone control is OFF so it was NOT sent. Tell the user to tap send.")
        val sent = svc.waitAndClick(9000) { n ->
            n.packageName?.toString() == WA && (n.contentDescription?.toString()?.trim().let { it.equals("Send", true) || it == "পাঠান" } ||
                n.text?.toString()?.trim().let { it.equals("Send", true) || it == "পাঠান" })
        }
        return res(if (sent) "ok: WhatsApp message sent to ${c.name}" else "ok: chat with ${c.name} opened and message typed, but the send button was not found. Use look_at_screen and tap Send.")
    }

    fun youtube(ctx: Context, svc: ZaraAccessibilityService?, query: String): JSONObject {
        if (query.isBlank()) return res("error: no song or video name given. Ask the user.")
        val i = Intent(Intent.ACTION_SEARCH).setPackage(YT).putExtra("query", query)
        launch(ctx, i)?.let {
            // YouTube app missing -> browser fallback
            launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8"))))
                ?.let { e -> return res("error: cannot open YouTube ($e)") }
            return res("ok: opened YouTube search for '$query' in the browser. Use look_at_screen to pick the first video.")
        }
        if (svc == null) return res("ok: YouTube search for '$query' opened, but phone control is OFF so the video was not started. Tell the user to tap the first result.")
        val played = svc.waitAndClick(12000) { n ->
            val d = n.contentDescription?.toString().orEmpty()
            n.packageName?.toString() == YT && d.isNotEmpty() &&
                (d.contains("play video", true) || d.contains("Go to channel", true)) &&
                !d.contains("Sponsored", true) && !d.startsWith("Ad", true)
        }
        return res(if (played) "ok: playing the first YouTube result for '$query'" else "ok: YouTube search for '$query' is open but the first video could not be picked automatically. Use look_at_screen then click it.")
    }

    /** Returns null if [name] is not a direct action. */
    fun execute(name: String, args: JSONObject, ctx: Context, svc: ZaraAccessibilityService?): JSONObject? = when (name) {
        "call_contact" -> call(ctx, args.optString("who"))
        "send_sms" -> sms(ctx, args.optString("who"), args.optString("message"))
        "send_whatsapp" -> whatsapp(ctx, svc, args.optString("who"), args.optString("message"))
        "play_youtube" -> youtube(ctx, svc, args.optString("query"))
        else -> null
    }
}
