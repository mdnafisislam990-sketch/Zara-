package com.zara.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val REST = "https://generativelanguage.googleapis.com/v1beta/models/"
private val JSON_TYPE = "application/json".toMediaType()

private fun errMsg(code: Int, body: String): String =
    try { JSONObject(body).getJSONObject("error").getString("message") } catch (_: Exception) { "Gemini error (HTTP $code)" }

/** Streaming text chat (replies appear word by word). Everything is saved to Memory. */
object ChatClient {
    private val http = OkHttpClient.Builder().readTimeout(90, TimeUnit.SECONDS).build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val _streaming = MutableStateFlow<String?>(null)
    val streaming: StateFlow<String?> = _streaming.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun ask(ctx: Context, text: String) {
        val app = ctx.applicationContext
        Memory.load(app)
        Memory.add("user", text, "chat")
        _error.value = null
        val key = Prefs.apiKey(app)
        if (key.isBlank()) { _error.value = "Add your Gemini API key in Settings > Connections"; return }
        job?.cancel()
        job = scope.launch { run(app, key) }
    }

    private fun buildBody(app: Context): JSONObject {
        val merged = ArrayList<Pair<String, String>>()
        Memory.messages().filter { it.role == "user" || it.role == "model" }.takeLast(30).forEach { m ->
            if (merged.isNotEmpty() && merged.last().first == m.role) {
                merged[merged.size - 1] = m.role to (merged.last().second + "\n" + m.text)
            } else merged.add(m.role to m.text)
        }
        while (merged.isNotEmpty() && merged.first().first != "user") merged.removeAt(0)
        val contents = JSONArray()
        merged.forEach { (r, t) ->
            contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        return JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", Persona.chat(app)))))
            .put("contents", contents)
    }

    private fun run(app: Context, key: String) {
        _streaming.value = ""
        val full = StringBuilder()
        try {
            val req = Request.Builder()
                .url("$REST${Prefs.textModel(app)}:streamGenerateContent?alt=sse")
                .header("x-goog-api-key", key)
                .post(buildBody(app).toString().toRequestBody(JSON_TYPE))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException(errMsg(resp.code, resp.body?.string().orEmpty()))
                val src = resp.body!!.source()
                while (!src.exhausted()) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val j = try { JSONObject(line.substring(5).trim()) } catch (_: Exception) { continue }
                    val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                    for (i in 0 until parts.length()) {
                        val t = parts.getJSONObject(i).optString("text")
                        if (t.isNotEmpty()) { full.append(t); _streaming.value = full.toString() }
                    }
                }
            }
            if (full.isBlank()) throw RuntimeException("Empty reply (the model may have blocked it)")
            Memory.add("model", full.toString(), "chat")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (full.isNotBlank()) Memory.add("model", full.toString(), "chat")
            _error.value = e.message ?: "Network error"
        } finally {
            _streaming.value = null
        }
    }
}

/** Text -> image with Gemini image generation. */
object ImageClient {
    private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()

    /** Returns (bitmap, errorMessage). */
    suspend fun generate(ctx: Context, prompt: String): Pair<Bitmap?, String?> = withContext(Dispatchers.IO) {
        val app = ctx.applicationContext
        val key = Prefs.apiKey(app)
        if (key.isBlank()) return@withContext null to "Add your Gemini API key in Settings > Connections"
        try {
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
            val req = Request.Builder()
                .url("$REST${Prefs.imageModel(app)}:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toString().toRequestBody(JSON_TYPE))
                .build()
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return@withContext null to errMsg(resp.code, text)
                val parts = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                var note = ""
                if (parts != null) for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val data = p.optJSONObject("inlineData")?.optString("data").orEmpty()
                    if (data.isNotEmpty()) {
                        val bytes = Base64.decode(data, Base64.DEFAULT)
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) {
                            Memory.add("action", "created an image: ${prompt.take(80)}", "chat")
                            return@withContext bmp to null
                        }
                    }
                    note += p.optString("text")
                }
                null to (note.ifBlank { "No image was returned. Try another prompt or change the image model in Settings > Connections." })
            }
        } catch (e: Exception) {
            null to (e.message ?: "Network error")
        }
    }
}
