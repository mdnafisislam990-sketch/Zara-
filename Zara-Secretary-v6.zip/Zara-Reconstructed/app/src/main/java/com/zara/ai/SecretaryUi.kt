package com.zara.ai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat

@Composable
internal fun SecretaryDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Secretary.enabled(ctx)) }
    var msg by remember { mutableStateOf(Secretary.autoMsg(ctx)) }
    var call by remember { mutableStateOf(Secretary.autoCall(ctx)) }
    var owner by remember { mutableStateOf(Secretary.owner(ctx)) }
    var name by remember { mutableStateOf(Secretary.assistant(ctx)) }
    var status by remember { mutableStateOf(Secretary.status(ctx)) }
    var delay by remember { mutableStateOf(Secretary.ringDelay(ctx).toString()) }
    val listenerOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun save() {
        Prefs.put(ctx, "sec_owner", owner); Prefs.put(ctx, "sec_name", name)
        Prefs.put(ctx, "sec_status", status); Prefs.put(ctx, "sec_delay", delay)
        Prefs.putBool(ctx, "sec_msg", msg); Prefs.putBool(ctx, "sec_call", call)
    }

    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        save(); Secretary.setEnabled(ctx, true); on = true
    }

    AlertDialog(
        onDismissRequest = onClose, containerColor = Card,
        title = { Text("Secretary mode", color = Color.White) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Secretary ON", color = Color.White); Text("Zara answers for $owner while you are away", color = Soft, fontSize = 11.sp) }
                    Switch(on, { v ->
                        if (v) perms.launch(arrayOf(
                            Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
                            Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.POST_NOTIFICATIONS))
                        else { Secretary.setEnabled(ctx, false); on = false }
                    })
                }
                OutlinedTextField(owner, { owner = it }, label = { Text("Your name (owner)") }, singleLine = true)
                OutlinedTextField(name, { name = it }, label = { Text("Assistant name") }, singleLine = true)
                OutlinedTextField(status, { status = it }, label = { Text("Status (e.g. he is out, driving, sleeping)") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Auto-reply to messages", color = Color.White); Text("WhatsApp, Messenger, Telegram, SMS", color = Soft, fontSize = 11.sp) }
                    Switch(msg, { msg = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Answer phone calls", color = Color.White); Text("Picks up and talks on speaker", color = Soft, fontSize = 11.sp) }
                    Switch(call, { call = it })
                }
                OutlinedTextField(delay, { delay = it.filter(Char::isDigit).take(2) }, label = { Text("Answer after (seconds of ringing)") }, singleLine = true)
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                    Text(if (listenerOn) "Notification access: ON (tap to manage)" else "1. Allow notification access (needed for messages)")
                }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                    Text("2. Battery: set Zara to Unrestricted / not optimized")
                }
                Text("The phone must stay powered on with internet. Screen off or locked is fine. After a phone restart open Zara once.", color = Soft, fontSize = 11.sp)
                Text("Call audio: Android does not let apps tap the call audio, so Zara talks through the loudspeaker and hears the caller through the mic. Works best with the phone lying in a quiet place.", color = Soft, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = { save(); onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
