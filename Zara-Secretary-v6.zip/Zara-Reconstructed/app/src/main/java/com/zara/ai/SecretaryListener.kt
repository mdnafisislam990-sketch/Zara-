package com.zara.ai

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Reads incoming chat notifications (works with the screen off / app closed) and answers them through the
 * notification's own "Reply" action, exactly like tapping Reply yourself.
 */
class SecretaryListener : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val seen = LinkedHashMap<String, Long>()
    private val mine = LinkedHashSet<String>()

    @Suppress("DEPRECATION")
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val ctx = applicationContext
        if (!Secretary.enabled(ctx) || !Secretary.autoMsg(ctx)) return
        val pkg = sbn.packageName
        if (pkg == packageName || pkg !in Secretary.APPS) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras ?: return
        if (ex.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return

        val sender = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        var text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        ex.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull()?.let { m ->
            (m as? Bundle)?.getCharSequence("text")?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { text = it }
        }
        if (sender.isBlank() || text.isBlank()) return
        if (sender.equals("You", true) || sender.equals("WhatsApp", true)) return
        if (Regex("^\\d+ new messages?$", RegexOption.IGNORE_CASE).matches(text)) return
        if (Regex("^[0-9+ ]{3,8}$").matches(sender)) return // bank / OTP short codes
        if (Regex("otp|verification code|one.time", RegexOption.IGNORE_CASE).containsMatchIn(text)) return

        val action = n.actions?.firstOrNull { a ->
            a.remoteInputs?.any { it.allowFreeFormInput } == true
        } ?: return

        val id = "$pkg|$sender|$text"
        synchronized(this) {
            if (mine.contains(text)) return           // this is our own reply echoed back
            val now = System.currentTimeMillis()
            seen.entries.removeAll { now - it.value > 120_000 }
            if (seen.containsKey(id)) return
            seen[id] = now
        }
        if (!Secretary.allowReply(sender)) return

        scope.launch {
            delay(2500) // looks natural, and lets the owner reply first if they are holding the phone
            val reply = Secretary.textReply(ctx, sender, appName(pkg), text) ?: return@launch
            try {
                val intent = Intent()
                val bundle = Bundle()
                action.remoteInputs.forEach { bundle.putCharSequence(it.resultKey, reply) }
                RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
                synchronized(this@SecretaryListener) { mine.add(reply); while (mine.size > 30) mine.remove(mine.first()) }
                action.actionIntent.send(ctx, 0, intent)
                Secretary.log(ctx, "$sender (${appName(pkg)}): $text  ->  Zara replied: $reply")
            } catch (_: Exception) {}
        }
    }

    private fun appName(pkg: String) = when (pkg) {
        "com.whatsapp", "com.whatsapp.w4b" -> "WhatsApp"
        "com.facebook.orca" -> "Messenger"
        "org.telegram.messenger" -> "Telegram"
        "com.instagram.android" -> "Instagram"
        else -> "SMS"
    }
}
