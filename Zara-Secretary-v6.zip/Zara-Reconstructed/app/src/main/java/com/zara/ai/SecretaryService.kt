package com.zara.ai

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * Always-on standby (foreground service). Watches the phone state; when a call rings and Secretary mode is on,
 * it answers after a short delay, puts the call on speaker and lets Gemini Live talk to the caller.
 */
class SecretaryService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var callback: Any? = null
    private var legacy: PhoneStateListener? = null
    @Volatile private var weAnswered = false
    private var answerTask: Runnable? = null
    private var hangupTask: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("zara_secretary", "Zara Secretary", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, "zara_secretary")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Zara Secretary is ON")
            .setContentText("Answering messages and calls for ${Secretary.owner(this)}")
            .setContentIntent(open).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(2, n)
        } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        register()
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun register() {
        if (callback != null || legacy != null) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        if (Build.VERSION.SDK_INT >= 31) {
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) { onCall(state) }
            }
            tm.registerTelephonyCallback(ContextCompat.getMainExecutor(this), cb)
            callback = cb
        } else {
            @Suppress("DEPRECATION")
            val l = object : PhoneStateListener() {
                @Deprecated("old API")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) { onCall(state) }
            }
            @Suppress("DEPRECATION") tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            legacy = l
        }
    }

    private fun onCall(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                if (!Secretary.enabled(this) || !Secretary.autoCall(this) || weAnswered) return
                if (LiveSession.state.value != CallState.IDLE) return // you are talking to Zara right now
                cancelAnswer()
                val t = Runnable { answer() }
                answerTask = t
                main.postDelayed(t, Secretary.ringDelay(this) * 1000L)
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (weAnswered) startTalking() else cancelAnswer() // owner picked up by hand
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                cancelAnswer()
                if (weAnswered) finishCall()
            }
        }
    }

    private fun cancelAnswer() { answerTask?.let { main.removeCallbacks(it) }; answerTask = null }

    @SuppressLint("MissingPermission")
    private fun answer() {
        answerTask = null
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) return
        try {
            weAnswered = true
            (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
        } catch (_: Exception) { weAnswered = false }
    }

    private fun startTalking() {
        if (LiveSession.state.value != CallState.IDLE && LiveSession.secretaryPrompt == null) return
        Secretary.log(this, "Answered a phone call for ${Secretary.owner(this)}")
        LiveSession.stop()
        LiveSession.secretaryPrompt = Secretary.voicePrompt(this)
        LiveSession.start(applicationContext)
        val h = Runnable { hangUp() }
        hangupTask = h
        main.postDelayed(h, 4 * 60 * 1000L) // never stay on a call longer than 4 minutes
    }

    @SuppressLint("MissingPermission")
    private fun hangUp() {
        try {
            if (Build.VERSION.SDK_INT >= 28 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED)
                (getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
        } catch (_: Exception) {}
    }

    private fun finishCall() {
        weAnswered = false
        hangupTask?.let { main.removeCallbacks(it) }; hangupTask = null
        LiveSession.stop()
        LiveSession.secretaryPrompt = null
        LiveSession.clear()
    }

    override fun onDestroy() {
        cancelAnswer()
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            if (Build.VERSION.SDK_INT >= 31) (callback as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            @Suppress("DEPRECATION") legacy?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (_: Exception) {}
        if (weAnswered) finishCall()
        super.onDestroy()
    }
}
